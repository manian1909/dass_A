import pytest
from datetime import datetime
from emarketing import EMarketingSystem, Product

@pytest.fixture
def system():
    return EMarketingSystem()

def test_user_registration(system):
    user = system.register_user("test_user", "password")
    assert user.username == "test_user"
    with pytest.raises(ValueError):
        system.register_user("test_user", "password")

def test_retail_store_registration(system):
    store = system.register_user("store1", "password", "retail", "ST001")
    assert store.store_id == "ST001"
    assert store.bulk_discount == 0.15

def test_product_management(system):
    product = system.add_product("Test Product", 100, "Electronics", 10)
    assert product.name == "Test Product"
    assert product.price == 100

def test_search_products(system):
    system.add_product("iPhone", 999, "Electronics", 5)
    system.add_product("Samsung TV", 799, "Electronics", 3)
    results = system.search_products("phone")
    assert len(results) == 1
    assert results[0].name == "iPhone"

def test_order_creation(system):
    user = system.register_user("customer1", "password")
    product = system.add_product("Test Product", 100, "Electronics", 10)
    order = system.create_order("customer1", [(product, 2)], "123 Test St")
    assert order.total == 200
    assert order.status == "Pending"

def test_bulk_order_discount(system):
    store = system.register_user("store1", "password", "retail", "ST001")
    product = system.add_product("Test Product", 100, "Electronics", 10)
    order = system.create_order("store1", [(product, 10)], "123 Store St")
    assert order.total == 850  # 1000 - 15% discount

def test_loyalty_points(system):
    user = system.register_user("customer1", "password")
    product = system.add_product("Test Product", 1000, "Electronics", 10)
    system.create_order("customer1", [(product, 1)], "123 Test St")
    assert system.users["customer1"].loyalty_points == 10

def test_coupon_generation(system):
    user = system.register_user("customer1", "password")
    product = system.add_product("Test Product", 10000, "Electronics", 10)
    system.create_order("customer1", [(product, 1)], "123 Test St")
    assert len(system.users["customer1"].discount_coupons) == 1
