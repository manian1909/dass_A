from abc import ABC, abstractmethod
from datetime import datetime
import uuid

class User(ABC):
    def __init__(self, username, password):
        self.username = username
        self.password = password
        self.order_history = []

class Customer(User):
    def __init__(self, username, password):
        super().__init__(username, password)
        self.discount_coupons = []
        self.loyalty_points = 0

class RetailStore(User):
    def __init__(self, username, password, store_id):
        super().__init__(username, password)
        self.store_id = store_id
        self.bulk_discount = 0.15  # 15% discount on bulk orders

class Product:
    def __init__(self, name, price, category, stock):
        self.id = str(uuid.uuid4())
        self.name = name
        self.price = price
        self.category = category
        self.stock = stock

class Coupon:
    def __init__(self, code, discount_percent, valid_until):
        self.code = code
        self.discount_percent = discount_percent
        self.valid_until = valid_until

class Order:
    def __init__(self, user, items, delivery_address):
        self.id = str(uuid.uuid4())
        self.user = user
        self.items = items  # List of (product, quantity) tuples
        self.delivery_address = delivery_address
        self.status = "Pending"
        self.total = self._calculate_total()
        
    def _calculate_total(self):
        total = sum(item[0].price * item[1] for item in self.items)
        if isinstance(self.user, RetailStore):
            total *= (1 - self.user.bulk_discount)
        return total

class EMarketingSystem:
    def __init__(self):
        self.users = {}
        self.products = {}
        self.orders = {}
        self.coupons = {}

    def register_user(self, username, password, user_type="customer", store_id=None):
        if username in self.users:
            raise ValueError("Username already exists")
        if user_type == "customer":
            self.users[username] = Customer(username, password)
        else:
            self.users[username] = RetailStore(username, password, store_id)
        return self.users[username]

    def add_product(self, name, price, category, stock):
        product = Product(name, price, category, stock)
        self.products[product.id] = product
        return product

    def search_products(self, query):
        return [p for p in self.products.values() 
                if query.lower() in p.name.lower() or 
                   query.lower() in p.category.lower()]

    def create_order(self, username, items, address):
        if username not in self.users:
            raise ValueError("User not found")
        order = Order(self.users[username], items, address)
        self.orders[order.id] = order
        self._update_loyalty_points(username, order.total)
        return order

    def _update_loyalty_points(self, username, order_total):
        user = self.users[username]
        if isinstance(user, Customer):
            user.loyalty_points += int(order_total // 100)  # 1 point per $100 spent
            if user.loyalty_points >= 100:
                self._generate_coupon(username)

    def _generate_coupon(self, username):
        code = f"LOYALTY{str(uuid.uuid4())[:8]}"
        coupon = Coupon(code, 10, datetime.now().date())
        self.users[username].discount_coupons.append(coupon)
        self.coupons[code] = coupon

    def update_order_status(self, order_id, status):
        if order_id not in self.orders:
            raise ValueError("Order not found")
        self.orders[order_id].status = status

def main():
    system = EMarketingSystem()
    while True:
        print("\n1. Register User")
        print("2. Add Product")
        print("3. Search Products")
        print("4. Create Order")
        print("5. Check Order Status")
        print("6. Exit")
        
        choice = input("Enter your choice: ")
        # Implementation of CLI menu options...

if __name__ == "__main__":
    main()
