import unittest
from datetime import datetime, timedelta
from q1 import *

class TestFoodDeliverySystem(unittest.TestCase):
    def setUp(self):
        self.system = FoodDeliverySystem()
        # Create sample data for testing
        self.restaurant = self.system.register_restaurant("Test Restaurant")
        self.restaurant.add_menu_item("Pizza", 299.99)
        self.restaurant.add_menu_item("Burger", 199.99)
        
        self.user = self.system.register_user("Test User")
        self.agent = self.system.register_delivery_agent("Test Agent")

    def test_user_registration(self):
        user = self.system.register_user("John Doe")
        self.assertIsInstance(user, User)
        self.assertEqual(user.name, "John Doe")
        self.assertTrue(user.user_id in self.system.users)

    def test_restaurant_registration(self):
        restaurant = self.system.register_restaurant("New Restaurant")
        self.assertIsInstance(restaurant, Restaurant)
        self.assertEqual(restaurant.name, "New Restaurant")
        self.assertTrue(restaurant.rest_id in self.system.restaurants)

    def test_delivery_agent_registration(self):
        agent = self.system.register_delivery_agent("New Agent")
        self.assertIsInstance(agent, DeliveryAgent)
        self.assertEqual(agent.name, "New Agent")
        self.assertTrue(agent.available)
        self.assertTrue(agent.agent_id in self.system.delivery_agents)

    def test_menu_management(self):
        self.restaurant.add_menu_item("Pasta", 249.99)
        self.assertEqual(self.restaurant.menu["Pasta"], 249.99)
        self.assertEqual(len(self.restaurant.menu), 3)

    def test_order_placement_delivery(self):
        items = {"Pizza": 2, "Burger": 1}
        order = self.system.place_order(
            self.user.user_id,
            self.restaurant.rest_id,
            items,
            OrderType.DELIVERY
        )
        
        self.assertIsInstance(order, Order)
        self.assertEqual(order.status, OrderStatus.PLACED)
        self.assertEqual(order.order_type, OrderType.DELIVERY)
        self.assertIsNotNone(order.delivery_agent)
        self.assertEqual(order.items, items)

    def test_order_placement_takeaway(self):
        items = {"Pizza": 1}
        order = self.system.place_order(
            self.user.user_id,
            self.restaurant.rest_id,
            items,
            OrderType.TAKEAWAY
        )
        
        self.assertIsInstance(order, Order)
        self.assertEqual(order.status, OrderStatus.PLACED)
        self.assertEqual(order.order_type, OrderType.TAKEAWAY)
        self.assertIsNone(order.delivery_agent)

    def test_order_total_calculation(self):
        items = {"Pizza": 2, "Burger": 1}
        order = self.system.place_order(
            self.user.user_id,
            self.restaurant.rest_id,
            items,
            OrderType.DELIVERY
        )
        
        expected_total = (299.99 * 2) + 199.99 + 50.0  # Items + delivery charge
        self.assertEqual(order.get_total_amount(), expected_total)

    def test_restaurant_stats(self):
        # Place multiple orders
        items1 = {"Pizza": 1}
        items2 = {"Burger": 1}
        
        self.system.place_order(self.user.user_id, self.restaurant.rest_id, items1, OrderType.DELIVERY)
        self.system.place_order(self.user.user_id, self.restaurant.rest_id, items2, OrderType.TAKEAWAY)
        
        stats = self.system.get_restaurant_stats(self.restaurant.rest_id)
        
        self.assertEqual(stats["total_orders"], 2)
        self.assertEqual(stats["delivery_orders"], 1)
        self.assertEqual(stats["takeaway_orders"], 1)
        expected_revenue = 299.99 + 50.0 + 199.99  # Pizza + delivery + Burger
        self.assertEqual(stats["total_revenue"], expected_revenue)

    def test_manager_verification(self):
        self.assertTrue(self.system.verify_manager("1911", self.restaurant.rest_id))
        self.assertFalse(self.system.verify_manager("wrong_id", self.restaurant.rest_id))

    def test_delivery_agent_status(self):
        # Place a delivery order to occupy the agent
        items = {"Pizza": 1}
        order = self.system.place_order(
            self.user.user_id,
            self.restaurant.rest_id,
            items,
            OrderType.DELIVERY
        )
        
        agents_status = self.system.get_delivery_agents_status()
        busy_agent = next(agent for agent in agents_status if not agent['available'])
        
        self.assertIsNotNone(busy_agent)
        self.assertEqual(busy_agent['current_order']['order_id'], order.order_id)

    def test_order_time_remaining(self):
        items = {"Pizza": 1}
        order = self.system.place_order(
            self.user.user_id,
            self.restaurant.rest_id,
            items,
            OrderType.DELIVERY
        )
        
        # Ensure we check just after order placement
        initial_time = order.get_time_remaining()
        self.assertTrue(0 <= initial_time <= 10, f"Initial time {initial_time} not in range [0,10]")
        
        # Simulate time passing
        order.placed_time = datetime.now() - timedelta(seconds=5)
        remaining_time = order.get_time_remaining()
        self.assertTrue(0 <= remaining_time <= 5, f"Remaining time {remaining_time} not in range [0,5]")

    def test_aggregate_items(self):
        # Place multiple orders with overlapping items
        items1 = {"Pizza": 2, "Burger": 1}
        items2 = {"Pizza": 1, "Burger": 2}
        
        self.system.place_order(self.user.user_id, self.restaurant.rest_id, items1, OrderType.DELIVERY)
        self.system.place_order(self.user.user_id, self.restaurant.rest_id, items2, OrderType.TAKEAWAY)
        
        aggregate = self.restaurant.get_aggregate_items()
        
        self.assertEqual(aggregate['items']['Pizza']['quantity'], 3)
        self.assertEqual(aggregate['items']['Burger']['quantity'], 3)
        # Calculate total: 3 Pizzas + 3 Burgers + 1 delivery charge
        pizza_total = 299.99 * 3
        burger_total = 199.99 * 3
        delivery_charge = 50.0  # One delivery order
        expected_total = pizza_total + burger_total + delivery_charge
        self.assertEqual(aggregate['total_amount'], expected_total)

if __name__ == '__main__':
    unittest.main()
