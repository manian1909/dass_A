from enum import Enum
from typing import List, Dict
import time
from datetime import datetime

class OrderType(Enum):
    DELIVERY = "delivery"
    TAKEAWAY = "takeaway"

class OrderStatus(Enum):
    PLACED = "placed"
    PREPARING = "preparing"
    OUT_FOR_DELIVERY = "out_for_delivery"
    READY_FOR_PICKUP = "ready_for_pickup"
    DELIVERED = "delivered"

class User:
    def __init__(self, user_id: str, name: str):
        self.user_id = user_id
        self.name = name
        self.orders: List[Order] = []

class DeliveryAgent:
    def __init__(self, agent_id: str, name: str):
        self.agent_id = agent_id
        self.name = name
        self.available = True
        self.current_order = None
        self.last_delivery_time = datetime.now()  # Track when agent last completed delivery

class Restaurant:
    def __init__(self, rest_id: str, name: str):
        self.rest_id = rest_id
        self.name = name
        self.menu: Dict[str, float] = {}
        self.orders: List[Order] = []
        self.manager_id = "1911"  # Fixed manager ID

    def add_menu_item(self, item: str, price: float):
        self.menu[item] = price

    def get_order_summary(self) -> List[Dict]:
        order_details = []
        for order in self.orders:
            detail = {
                'order_id': order.order_id,
                'user_id': order.user.user_id,
                'user_name': order.user.name,
                'items': order.items,
                'total': order.get_total_amount(),
                'type': order.order_type.value,
                'status': order.status.value,
                'delivery_agent': order.delivery_agent.name if order.delivery_agent else None,
                'time_remaining': order.get_time_remaining()
            }
            order_details.append(detail)
        return order_details

    def get_aggregate_items(self) -> Dict:
        aggregated = {}
        total_amount = 0
        delivery_charges = 0
        for order in self.orders:
            for item, qty in order.items.items():
                if item not in aggregated:
                    aggregated[item] = {
                        'quantity': 0,
                        'price_per_unit': self.menu[item],
                        'total_price': 0
                    }
                aggregated[item]['quantity'] += qty
                aggregated[item]['total_price'] = aggregated[item]['quantity'] * self.menu[item]
                total_amount += qty * self.menu[item]
            
            # Add delivery charge if it's a delivery order
            if order.order_type == OrderType.DELIVERY:
                delivery_charges += 50.0
                
        total_amount += delivery_charges
        return {'items': aggregated, 'total_amount': total_amount}

class Order:
    def __init__(self, order_id: str, user: User, restaurant: Restaurant, items: Dict[str, int], order_type: OrderType):
        self.order_id = order_id
        self.user = user
        self.restaurant = restaurant
        self.items = items
        self.order_type = order_type
        self.status = OrderStatus.PLACED
        self.placed_time = datetime.now()
        self.estimated_time = 10  # Changed to 10 seconds
        self.delivery_agent = None
        self.delivery_started_time = None
        self.delivery_completed_time = None
        self.preparation_complete_time = None

    def get_total_amount(self) -> float:
        base_amount = sum(self.restaurant.menu[item] * qty for item, qty in self.items.items())
        delivery_charge = 50.0 if self.order_type == OrderType.DELIVERY else 0.0
        return base_amount + delivery_charge

    def get_time_remaining(self) -> int:
        if self.delivery_completed_time:
            return 0
        
        current_time = datetime.now()
        if not self.preparation_complete_time:
            # During preparation phase
            elapsed = (current_time - self.placed_time).total_seconds()
            return max(0, 10 - int(elapsed))  # 10 seconds prep time
        
        if self.status == OrderStatus.OUT_FOR_DELIVERY:
            elapsed = (current_time - self.delivery_started_time).total_seconds()
            return max(0, 10 - int(elapsed))  # 10 seconds delivery time
        
        return 0

    def start_delivery(self):
        self.delivery_started_time = datetime.now()
        self.status = OrderStatus.OUT_FOR_DELIVERY

    def complete_delivery(self):
        self.delivery_completed_time = datetime.now()
        self.status = OrderStatus.DELIVERED

class Manager:
    def __init__(self, manager_id: str, name: str):
        self.manager_id = manager_id
        self.name = name

class FoodDeliverySystem:
    _instance = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(FoodDeliverySystem, cls).__new__(cls)
            cls._instance.initialize()
        return cls._instance

    def initialize(self):
        self.users: Dict[str, User] = {}
        self.restaurants: Dict[str, Restaurant] = {}
        self.delivery_agents: Dict[str, DeliveryAgent] = {}
        self.orders: Dict[str, Order] = {}
        self.managers: Dict[str, Manager] = {}
        self.order_counter = 0

    def register_user(self, name: str) -> User:
        user_id = f"U{len(self.users) + 1}"
        user = User(user_id, name)
        self.users[user_id] = user
        return user

    def register_restaurant(self, name: str) -> Restaurant:
        rest_id = f"R{len(self.restaurants) + 1}"
        restaurant = Restaurant(rest_id, name)
        self.restaurants[rest_id] = restaurant
        return restaurant

    def register_delivery_agent(self, name: str) -> DeliveryAgent:
        agent_id = f"D{len(self.delivery_agents) + 1}"
        agent = DeliveryAgent(agent_id, name)
        self.delivery_agents[agent_id] = agent
        return agent

    def register_manager(self, name: str) -> Manager:
        manager_id = f"M{len(self.managers) + 1}"
        manager = Manager(manager_id, name)
        self.managers[manager_id] = manager
        return manager

    def place_order(self, user_id: str, rest_id: str, items: Dict[str, int], order_type: OrderType) -> Order:
        self.order_counter += 1
        order_id = f"O{self.order_counter}"
        
        order = Order(
            order_id,
            self.users[user_id],
            self.restaurants[rest_id],
            items,
            order_type
        )
        
        self.orders[order_id] = order
        self.users[user_id].orders.append(order)
        self.restaurants[rest_id].orders.append(order)
        
        if order_type == OrderType.DELIVERY:
            self._assign_delivery_agent(order)
            
        return order

    def _assign_delivery_agent(self, order: Order):
        available_agents = [agent for agent in self.delivery_agents.values() if agent.available]
        if not available_agents:
            return  # No available agents
            
        # Sort agents by last delivery time to implement FCFS
        available_agents.sort(key=lambda x: x.last_delivery_time)
        
        # Assign to the agent who has been waiting the longest
        agent = available_agents[0]
        agent.available = False
        agent.current_order = order
        order.delivery_agent = agent
        
        # Start a background thread to simulate delivery progress
        import threading
        threading.Thread(target=self._simulate_delivery_progress, args=(order,), daemon=True).start()

    def _simulate_delivery_progress(self, order: Order):
        # Simulate order preparation (10 seconds)
        time.sleep(10)
        order.preparation_complete_time = datetime.now()
        
        if order.order_type == OrderType.DELIVERY:
            # Start delivery
            order.start_delivery()
            # Simulate delivery time (10 seconds)
            time.sleep(10)
            # Complete delivery and move agent to end of queue
            order.complete_delivery()
            if order.delivery_agent:
                order.delivery_agent.available = True
                order.delivery_agent.last_delivery_time = datetime.now()
                order.delivery_agent.current_order = None
        else:
            # For takeaway, mark as ready for pickup after preparation
            order.status = OrderStatus.READY_FOR_PICKUP

    def update_order_status(self, order_id: str, status: OrderStatus):
        order = self.orders[order_id]
        order.status = status
        
        if status == OrderStatus.DELIVERED and order.delivery_agent:
            order.delivery_agent.available = True
            order.delivery_agent.current_order = None

    def get_restaurant_orders(self, rest_id: str) -> List[Order]:
        if rest_id in self.restaurants:
            return self.restaurants[rest_id].orders
        return []

    def get_restaurant_stats(self, rest_id: str) -> Dict:
        if rest_id not in self.restaurants:
            return {}
        
        restaurant = self.restaurants[rest_id]
        total_orders = len(restaurant.orders)
        delivery_orders = len([o for o in restaurant.orders if o.order_type == OrderType.DELIVERY])
        takeaway_orders = total_orders - delivery_orders
        total_revenue = sum(order.get_total_amount() for order in restaurant.orders)
        
        return {
            "total_orders": total_orders,
            "delivery_orders": delivery_orders,
            "takeaway_orders": takeaway_orders,
            "total_revenue": total_revenue
        }

    def verify_manager(self, manager_id: str, rest_id: str) -> bool:
        if rest_id in self.restaurants:
            return self.restaurants[rest_id].manager_id == manager_id
        return False

    def get_delivery_agents_status(self) -> List[Dict]:
        agents_status = []
        for agent in self.delivery_agents.values():
            status = {
                'agent_id': agent.agent_id,
                'name': agent.name,
                'available': agent.available,
                'current_order': None
            }
            if agent.current_order:
                status['current_order'] = {
                    'order_id': agent.current_order.order_id,
                    'user_name': agent.current_order.user.name,
                    'time_remaining': agent.current_order.get_time_remaining()
                }
            agents_status.append(status)
        return agents_status

class CLI:
    def __init__(self):
        self.system = FoodDeliverySystem()
        self.current_user = None
        self.current_manager = None

    def start(self):
        while True:
            if not self.current_user and not self.current_manager:
                self._show_auth_menu()
            elif self.current_manager:
                self._show_manager_menu()
            else:
                self._show_main_menu()

    def _show_auth_menu(self):
        print("\n1. Login as User\n2. Register User\n3. Login as Manager\n4. Exit")
        choice = input("Choose an option: ")
        
        if choice == "1":
            user_id = input("Enter user ID: ")
            if user_id in self.system.users:
                self.current_user = self.system.users[user_id]
            else:
                print("User not found!")
        elif choice == "2":
            name = input("Enter your name: ")
            user = self.system.register_user(name)
            print(f"Registered! Your user ID is: {user.user_id}")
        elif choice == "3":
            manager_id = input("Enter manager ID: ")
            if manager_id == "1911":
                manager = Manager("1911", "Restaurant Manager")
                self.current_manager = manager
            else:
                print("Manager not found!")
        elif choice == "4":
            exit()

    def _show_main_menu(self):
        print(f"\nWelcome {self.current_user.name}!")
        print("1. Place Order\n2. View Orders\n3. Logout")
        
        choice = input("Choose an option: ")
        
        if choice == "1":
            self._place_order()
        elif choice == "2":
            self._view_orders()
        elif choice == "3":
            self.current_user = None

    def _show_manager_menu(self):
        print(f"\nManager Dashboard - {self.current_manager.name}")
        print("1. View Detailed Orders")
        print("2. View Aggregate Order Summary")
        print("3. View Delivery Agents Status")
        print("4. Logout")
        
        choice = input("Choose an option: ")
        
        if choice == "1":
            self._view_detailed_orders()
        elif choice == "2":
            self._view_aggregate_orders()
        elif choice == "3":
            self._view_delivery_agents_status()
        elif choice == "4":
            self.current_manager = None

    def _place_order(self):
        print("\nAvailable Restaurants:")
        for rest in self.system.restaurants.values():
            print(f"{rest.rest_id}: {rest.name}")
        
        rest_id = input("Choose restaurant ID: ")
        if rest_id not in self.system.restaurants:
            print("Invalid restaurant!")
            return
            
        restaurant = self.system.restaurants[rest_id]
        items = {}
        
        print("\nMenu:")
        for item, price in restaurant.menu.items():
            print(f"{item}: ₹{price}")
            
        while True:
            item = input("\nEnter item (or done to finish): ")
            if item.lower() == "done":
                break
            if item not in restaurant.menu:
                print("Invalid item!")
                continue
            qty = int(input("Enter quantity: "))
            items[item] = qty

        order_type = OrderType.DELIVERY if input("\nDelivery? (y/n): ").lower() == 'y' else OrderType.TAKEAWAY
        
        order = self.system.place_order(self.current_user.user_id, rest_id, items, order_type)
        print(f"Order placed! Order ID: {order.order_id}")

    def _view_orders(self):
        for order in self.current_user.orders:
            print(f"\nOrder {order.order_id}")
            print(f"Restaurant: {order.restaurant.name}")
            print(f"Status: {order.status.value}")
            print(f"Order Type: {order.order_type.value}")
            
            time_remaining = order.get_time_remaining()
            if order.status == OrderStatus.PLACED:
                print("Order is being prepared")
                print(f"Time remaining for preparation: {time_remaining} seconds")
            elif order.status == OrderStatus.OUT_FOR_DELIVERY:
                print(f"Out for delivery with {order.delivery_agent.name}")
                print(f"Time remaining for delivery: {time_remaining} seconds")
            elif order.status == OrderStatus.READY_FOR_PICKUP:
                print("Order is ready for pickup")
            elif order.status == OrderStatus.DELIVERED:
                print("Order has been delivered")
            
            print("\nOrdered Items:")
            for item, qty in order.items.items():
                price_per_item = order.restaurant.menu[item]
                total_item_price = price_per_item * qty
                print(f"  - {item}: {qty} x ₹{price_per_item:.2f} = ₹{total_item_price:.2f}")
            if order.order_type == OrderType.DELIVERY:
                print(f"Delivery Charge: ₹50.00")
            print(f"Total amount: ₹{order.get_total_amount():.2f}")

    def _view_detailed_orders(self):
        rest_id = "R1"  # Since there's only one restaurant
        if not self.system.verify_manager(self.current_manager.manager_id, rest_id):
            print("Unauthorized access!")
            return

        restaurant = self.system.restaurants[rest_id]
        orders = restaurant.get_order_summary()
        
        print("\n=== Detailed Order Summary ===")
        for order in orders:
            print(f"\nOrder ID: {order['order_id']}")
            print(f"User: {order['user_id']} ({order['user_name']})")
            print(f"Order Type: {order['type']}")
            print(f"Status: {order['status']}")
            if order['delivery_agent']:
                print(f"Delivery Agent: {order['delivery_agent']}")
            if order['time_remaining'] > 0:
                print(f"Time Remaining: {order['time_remaining']} seconds")
            print("Items:")
            for item, qty in order['items'].items():
                price = restaurant.menu[item] * qty
                print(f"  - {item}: {qty} x ₹{restaurant.menu[item]} = ₹{price:.2f}")
            if order['type'] == OrderType.DELIVERY.value:
                print(f"Delivery Charge: ₹50.00")
            print(f"Total Amount: ₹{order['total']:.2f}")

    def _view_aggregate_orders(self):
        rest_id = "R1"  # Since there's only one restaurant
        if not self.system.verify_manager(self.current_manager.manager_id, rest_id):
            print("Unauthorized access!")
            return

        restaurant = self.system.restaurants[rest_id]
        summary = restaurant.get_aggregate_items()
        
        print("\n=== Aggregate Order Summary ===")
        print("\nItems to be prepared:")
        for item, details in summary['items'].items():
            print(f"{item}:")
            print(f"  Quantity: {details['quantity']}")
            print(f"  Total Price: ₹{details['total_price']:.2f}")
        
        print(f"\nTotal Revenue: ₹{summary['total_amount']:.2f}")

    def _view_delivery_agents_status(self):
        agents_status = self.system.get_delivery_agents_status()
        
        print("\n=== Delivery Agents Status ===")
        for agent in agents_status:
            print(f"\nAgent: {agent['name']} ({agent['agent_id']})")
            print(f"Status: {'Available' if agent['available'] else 'Busy'}")
            
            if agent['current_order']:
                order = agent['current_order']
                print(f"Current Delivery:")
                print(f"  Order ID: {order['order_id']}")
                print(f"  Customer: {order['user_name']}")
                print(f"  Time Remaining: {order['time_remaining']} seconds")
            else:
                print("No current delivery")

def initialize_sample_data(system):
    restaurant1 = system.register_restaurant("Sample Restaurant")
    restaurant1.add_menu_item("Pizza", 299.99)
    restaurant1.add_menu_item("Taco", 149.99)
    restaurant1.add_menu_item("Burger", 199.99)
    
    # Register multiple delivery agents
    system.register_delivery_agent("John Doe")
    system.register_delivery_agent("Jane Smith")
    system.register_delivery_agent("Mike Johnson")
    system.register_delivery_agent("Sarah Wilson")

if __name__ == "__main__":
    cli = CLI()
    initialize_sample_data(cli.system)
    print("Welcome to Food Delivery System!")
    print("Sample restaurants and delivery agents have been added.")
    print("Please register or login to continue.")
    cli.start()
