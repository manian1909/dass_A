"""Module for representing pieces in the Gobblet game."""

class Piece:
    """Class representing a single game piece with player and size attributes."""
    def __init__(self, player, size):
        """Initialize a piece with player number and size.
        
        Args:
            player (int): Player number (1 or 2)
            size (int): Size of piece (0=smallest to 2=largest)
        """
        self.player = player  # 1 or 2
        self.size = size    # 0 (smallest) to 2 (largest)