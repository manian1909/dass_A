import pygame
import sys
from board import Board
from piece import Piece

class GobbletGame:
    def __init__(self):
        pygame.init()
        self.WINDOW_SIZE = 650  # Increased window size
        self.CELL_SIZE = self.WINDOW_SIZE // 3
        
        # Adjust piece size multiplier
        self.PIECE_SIZE_MULTIPLIER = self.CELL_SIZE // 15  # Smaller pieces
        
        # Add reserve area dimensions
        self.RESERVE_HEIGHT = 100
        self.BOARD_MARGIN = 50  # Add margin around board for pieces
        screen_height = self.WINDOW_SIZE + self.RESERVE_HEIGHT
        self.screen = pygame.display.set_mode((self.WINDOW_SIZE + 2 * self.BOARD_MARGIN, self.WINDOW_SIZE + 2 * self.BOARD_MARGIN))
        pygame.display.set_caption('Gobblet Game (3x3)')
        
        self.board = Board()
        self.selected_piece = None
        self.current_player = 1
        self.winner = None
        self.font = pygame.font.Font(None, 36)
        
        # Colors
        self.BLACK = (0, 0, 0)
        self.WHITE = (255, 255, 255)
        self.GRAY = (128, 128, 128)
        self.RED = (255, 0, 0)
        self.YELLOW = (255, 255, 0)

        self.zoom = 1.0
        self.perspective = 1.0
        self.shadow_pos = None
        self.dragging = False
        self.drag_piece = None
        self.drag_pos = None

        self.ZOOM_FACTOR = 1.0
        self.selected_piece = None
        self.shadow_pos = None
        self.dragging = False
        self.dragging_piece = None
        self.drag_start = None
        self.drag_offset = None
        self.dragging_piece_size = None

        self.touched_piece = None  # Track touched piece for touch-move rule
        self.must_move_touched = False  # Flag to enforce touch-move rule
        self.last_clicked_pos = None

    def draw_board(self):
        self.screen.fill(self.WHITE)
        board_offset = self.BOARD_MARGIN
        
        # Draw shadow for dragged piece
        if self.dragging and self.shadow_pos:
            row, col = self.shadow_pos
            shadow_radius = (self.dragging_piece_size + 1) * self.PIECE_SIZE_MULTIPLIER
            shadow_center = (col * self.CELL_SIZE + self.CELL_SIZE // 2 + board_offset,
                           row * self.CELL_SIZE + self.CELL_SIZE // 2 + board_offset)
            pygame.draw.circle(self.screen, self.GRAY, shadow_center, shadow_radius, 3)

        # Apply zoom
        scaled_cell_size = int(self.CELL_SIZE * self.ZOOM_FACTOR)
        board_offset = self.BOARD_MARGIN
        
        # Draw the main board
        for i in range(3):
            for j in range(3):
                pygame.draw.rect(self.screen, self.BLACK,
                               (j * scaled_cell_size + board_offset, 
                                i * scaled_cell_size + board_offset,
                                scaled_cell_size, scaled_cell_size), 2)
        
        # Draw pieces on board with zoom
        for i in range(3):
            for j in range(3):
                pieces = self.board.get_stack(i, j)
                if pieces:
                    top_piece = pieces[-1]
                    color = self.YELLOW if top_piece.player == 1 else self.RED
                    radius = int((top_piece.size + 1) * self.PIECE_SIZE_MULTIPLIER * self.ZOOM_FACTOR)
                    center = (j * scaled_cell_size + scaled_cell_size // 2 + board_offset,
                            i * scaled_cell_size + scaled_cell_size // 2 + board_offset)
                    pygame.draw.circle(self.screen, color, center, radius)

        # Draw Red pieces along top edge (AB) - Update the order
        y = self.BOARD_MARGIN // 2
        x = self.BOARD_MARGIN
        for size in [0, 1, 2]:  # Changed order to show small to large
            for piece in self.board.reserve_pieces[2][2-size]:  # Reverse index to match display
                radius = (2-size + 1) * 20
                pygame.draw.circle(self.screen, self.RED, (x + self.CELL_SIZE // 2, y), radius)
                x += self.CELL_SIZE

        # Draw Yellow pieces along bottom edge (CD) - Update the order
        y = self.WINDOW_SIZE + self.BOARD_MARGIN * 1.5
        x = self.BOARD_MARGIN
        for size in [0, 1, 2]:  # Changed order to show small to large
            for piece in self.board.reserve_pieces[1][2-size]:  # Reverse index to match display
                radius = (2-size + 1) * 20
                pygame.draw.circle(self.screen, self.YELLOW, (x + self.CELL_SIZE // 2, y), radius)
                x += self.CELL_SIZE

        # Draw shadow if piece is selected and dragging
        if self.dragging and self.shadow_pos:
            row, col = self.shadow_pos
            shadow_radius = int(30 * self.ZOOM_FACTOR)  # Fixed shadow size
            shadow_center = (col * scaled_cell_size + scaled_cell_size // 2 + board_offset,
                           row * scaled_cell_size + scaled_cell_size // 2 + board_offset)
            pygame.draw.circle(self.screen, self.GRAY, shadow_center, shadow_radius, 2)

        # Draw dragged piece at cursor position if dragging
        if self.dragging and self.drag_pos:
            color = self.YELLOW if self.current_player == 1 else self.RED
            radius = (self.dragging_piece_size + 1) * self.PIECE_SIZE_MULTIPLIER
            pygame.draw.circle(self.screen, color, self.drag_pos, radius)

        # Draw game info
        player_text = f"Current Player: {'YELLOW' if self.current_player == 1 else 'Red'}"
        text_surface = self.font.render(player_text, True, self.BLACK)
        self.screen.blit(text_surface, (self.BOARD_MARGIN, 10))

        if self.winner:
            winner_text = f"Winner: {'YELLOW' if self.winner == 1 else 'Red'}!"
            text_surface = self.font.render(winner_text, True, self.BLACK)
            self.screen.blit(text_surface, (self.WINDOW_SIZE // 2, 10))

    def handle_click(self, pos):
        if self.winner:
            return

        x, y = pos
        board_offset = self.BOARD_MARGIN

        # Convert screen coordinates to board coordinates
        board_x = x - board_offset
        board_y = y - board_offset
        row = int(board_y // self.CELL_SIZE)
        col = int(board_x // self.CELL_SIZE)

        # Check if clicking in the top row (Red pieces)
        if y < board_offset and self.current_player == 2:
            piece_x = (x - board_offset) // self.CELL_SIZE
            if 0 <= piece_x < 3:
                size = 2 - piece_x
                if self.board.reserve_pieces[2][size]:
                    self.selected_piece = ('reserve', 2, size)
                    self.dragging = True
                    self.drag_pos = pos
                    self.dragging_piece_size = size
            return

        # Check if clicking in the bottom row (Yellow pieces)
        if y > self.WINDOW_SIZE + board_offset and self.current_player == 1:
            piece_x = (x - board_offset) // self.CELL_SIZE
            if 0 <= piece_x < 3:
                size = 2 - piece_x
                if self.board.reserve_pieces[1][size]:
                    self.selected_piece = ('reserve', 1, size)
                    self.dragging = True
                    self.drag_pos = pos
                    self.dragging_piece_size = size
            return

        # Handle board clicks
        if 0 <= row < 3 and 0 <= col < 3:
            if not self.selected_piece:
                stack = self.board.get_stack(row, col)
                if stack and stack[-1].player == self.current_player:
                    self.selected_piece = (row, col)
                    self.dragging = True
                    self.drag_pos = pos
                    self.dragging_piece_size = stack[-1].size
            else:
                if isinstance(self.selected_piece, tuple):
                    if self.selected_piece[0] == 'reserve':
                        _, player, size = self.selected_piece
                        if self.board.place_from_reserve(player, size, row, col):
                            self.current_player = 3 - self.current_player
                            self.winner = self.board.check_winner()
                    else:
                        src_row, src_col = self.selected_piece
                        if self.board.is_valid_move(src_row, src_col, row, col, self.current_player):
                            self.board.move_piece(src_row, src_col, row, col)
                            self.current_player = 3 - self.current_player
                            self.winner = self.board.check_winner()
                
                self.selected_piece = None
                self.dragging = False
                self.drag_pos = None

    def run(self):
        running = True
        while running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    self.drag_start = event.pos
                    self.handle_click(event.pos)
                elif event.type == pygame.MOUSEBUTTONUP:
                    if self.dragging:
                        x, y = event.pos
                        board_offset = self.BOARD_MARGIN
                        board_x = (x - board_offset) // self.CELL_SIZE
                        board_y = (y - board_offset) // self.CELL_SIZE
                        row = int(board_y)
                        col = int(board_x)
                        
                        if 0 <= row < 3 and 0 <= col < 3:
                            if isinstance(self.selected_piece, tuple) and self.selected_piece[0] == 'reserve':
                                _, player, size = self.selected_piece
                                if self.board.place_from_reserve(player, size, row, col):
                                    self.current_player = 3 - self.current_player
                                    self.winner = self.board.check_winner()
                            else:
                                src_row, src_col = self.selected_piece
                                if self.board.is_valid_move(src_row, src_col, row, col, self.current_player):
                                    self.board.move_piece(src_row, src_col, row, col)
                                    self.current_player = 3 - self.current_player
                                    self.winner = self.board.check_winner()
                        
                        self.dragging = False
                        self.selected_piece = None
                        self.shadow_pos = None
                        self.drag_pos = None
                        self.dragging_piece_size = None

                elif event.type == pygame.MOUSEMOTION:
                    if self.dragging:
                        self.drag_pos = event.pos
                        x, y = event.pos
                        board_offset = self.BOARD_MARGIN
                        board_x = (x - board_offset) // self.CELL_SIZE
                        board_y = (y - board_offset) // self.CELL_SIZE
                        if 0 <= board_x < 3 and 0 <= board_y < 3:
                            self.shadow_pos = (board_y, board_x)
                        else:
                            self.shadow_pos = None
            
            self.draw_board()
            pygame.display.flip()
        
        pygame.quit()
        sys.exit()

if __name__ == "__main__":
    game = GobbletGame()
    game.run()
