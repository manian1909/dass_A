"""Module for managing the Gobblet game board state."""

from piece2 import Piece

class Board:
    """Class representing the game board and piece management."""
    
    def __init__(self):
        """Initialize an empty board and reserve pieces for both players."""
        self.board = [[[] for _ in range(3)] for _ in range(3)]
        self.reserve_pieces = {
            1: {
                2: [Piece(1, 2), Piece(1, 2)],  # Large pieces
                1: [Piece(1, 1), Piece(1, 1)],  # Medium pieces
                0: [Piece(1, 0), Piece(1, 0)]   # Small pieces
            },
            2: {
                2: [Piece(2, 2), Piece(2, 2)],
                1: [Piece(2, 1), Piece(2, 1)],
                0: [Piece(2, 0), Piece(2, 0)]
            }
        }

    def get_stack(self, row, col):
        """Get the stack of pieces at the specified position."""
        return self.board[row][col]

    def is_valid_move(self, src_row, src_col, dst_row, dst_col, player):
        """Check if a move is valid according to game rules."""
        if not (0 <= src_row < 3 and 0 <= src_col < 3 and 
                0 <= dst_row < 3 and 0 <= dst_col < 3):
            return False

        src_stack = self.board[src_row][src_col]
        dst_stack = self.board[dst_row][dst_col]

        if not src_stack:
            return False

        moving_piece = src_stack[-1]
        if moving_piece.player != player:
            return False

        if dst_stack and moving_piece.size <= dst_stack[-1].size:
            return False

        return True

    def move_piece(self, src_row, src_col, dst_row, dst_col):
        """Move a piece from source to destination position."""
        piece = self.board[src_row][src_col].pop()
        self.board[dst_row][dst_col].append(piece)

    def check_winner(self):
        """Check if there's a winner and return the winning player number."""
        for row in range(3):
            for player in [1, 2]:
                if all(self.board[row][col] and 
                       self.board[row][col][-1].player == player 
                       for col in range(3)):
                    return player

        for col in range(3):
            for player in [1, 2]:
                if all(self.board[row][col] and 
                       self.board[row][col][-1].player == player 
                       for row in range(3)):
                    return player

        for player in [1, 2]:
            if all(self.board[i][i] and 
                   self.board[i][i][-1].player == player 
                   for i in range(3)):
                return player
            if all(self.board[i][2-i] and 
                   self.board[i][2-i][-1].player == player 
                   for i in range(3)):
                return player

        return None

    def place_from_reserve(self, player, size, row, col):
        """Place a piece from reserve onto the board."""
        if not self.reserve_pieces[player][size]:
            return False
            
        dst_stack = self.board[row][col]
        if dst_stack and size <= dst_stack[-1].size:
            return False
            
        piece = self.reserve_pieces[player][size].pop()
        self.board[row][col].append(piece)
        return True