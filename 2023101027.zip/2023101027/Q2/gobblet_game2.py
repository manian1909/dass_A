"""Main module for the Gobblet game implementation using Pygame."""

import sys
import pygame
from board2 import Board

class GobbletGame:
    """Main game class handling the GUI and game logic."""

    def __init__(self):
        """Initialize the game window and game state."""
        pygame.init()
        self.window_size = 650
        self.cell_size = self.window_size // 3
        self.piece_size_mult = self.cell_size // 15
        self.reserve_height = 100
        self.board_margin = 50

        screen_height = self.window_size + self.reserve_height
        self.screen = pygame.display.set_mode((
            self.window_size + 2 * self.board_margin,
            self.window_size + 2 * self.board_margin
        ))
        pygame.display.set_caption('Gobblet Game (3x3)')

        # Game state
        self.board = Board()
        self.current_player = 1
        self.winner = None
        self.font = pygame.font.Font(None, 36)

        # Colors
        self.colors = {
            'black': (0, 0, 0),
            'white': (255, 255, 255),
            'gray': (128, 128, 128),
            'red': (255, 0, 0),
            'yellow': (255, 255, 0)
        }

        # Display state
        self.zoom = 1.0
        self.perspective = 1.0
        self.selected_piece = None
        self.shadow_pos = None
        self.dragging = False
        self.drag_piece = None
        self.drag_pos = None
        self.drag_start = None
        self.drag_offset = None
        self.dragging_piece_size = None

        # Game rules state
        self.touched_piece = None
        self.must_move_touched = False
        self.last_clicked_pos = None

    def draw_board(self):
        """Draw the game board and all pieces."""
        self.screen.fill(self.colors['white'])
        board_offset = self.board_margin

        # Draw shadow for dragged piece
        if self.dragging and self.shadow_pos:
            self._draw_shadow()

        # Draw board grid
        self._draw_grid()

        # Draw pieces
        self._draw_pieces()

        # Draw reserve pieces
        self._draw_reserve_pieces()

        # Draw game info
        self._draw_game_info()

    def _draw_shadow(self):
        """Draw shadow for currently dragged piece."""
        row, col = self.shadow_pos
        shadow_radius = (self.dragging_piece_size + 1) * self.piece_size_mult
        shadow_center = (
            col * self.cell_size + self.cell_size // 2 + self.board_margin,
            row * self.cell_size + self.cell_size // 2 + self.board_margin
        )
        pygame.draw.circle(
            self.screen,
            self.colors['gray'],
            shadow_center,
            shadow_radius,
            3
        )

    def _draw_grid(self):
        """Draw the game board grid."""
        for i in range(3):
            for j in range(3):
                pygame.draw.rect(
                    self.screen,
                    self.colors['black'],
                    (
                        j * self.cell_size + self.board_margin,
                        i * self.cell_size + self.board_margin,
                        self.cell_size,
                        self.cell_size
                    ),
                    2
                )

    def _draw_pieces(self):
        """Draw all pieces on the board."""
        for i in range(3):
            for j in range(3):
                pieces = self.board.get_stack(i, j)
                if pieces:
                    top_piece = pieces[-1]
                    color = (self.colors['yellow'] if top_piece.player == 1 
                            else self.colors['red'])
                    radius = (top_piece.size + 1) * self.piece_size_mult
                    center = (
                        j * self.cell_size + self.cell_size // 2 + self.board_margin,
                        i * self.cell_size + self.cell_size // 2 + self.board_margin
                    )
                    pygame.draw.circle(self.screen, color, center, radius)

    def _draw_reserve_pieces(self):
        """Draw reserve pieces for both players."""
        self._draw_player_reserve(2, self.board_margin // 2)  # Red pieces
        self._draw_player_reserve(
            1,
            self.window_size + self.board_margin * 1.5
        )  # Yellow pieces

    def _draw_player_reserve(self, player, y_pos):
        """Draw reserve pieces for a specific player."""
        x_pos = self.board_margin
        color = self.colors['red'] if player == 2 else self.colors['yellow']
        
        for size in range(3):
            for piece in self.board.reserve_pieces[player][2-size]:
                radius = (2-size + 1) * 20
                pygame.draw.circle(
                    self.screen,
                    color,
                    (x_pos + self.cell_size // 2, y_pos),
                    radius
                )
                x_pos += self.cell_size

    def _draw_game_info(self):
        """Draw game status information."""
        player_text = (f"Current Player: "
                      f"{'YELLOW' if self.current_player == 1 else 'RED'}")
        text_surface = self.font.render(
            player_text,
            True,
            self.colors['black']
        )
        self.screen.blit(text_surface, (self.board_margin, 10))

        if self.winner:
            winner_text = (f"Winner: "
                         f"{'YELLOW' if self.winner == 1 else 'RED'}!")
            text_surface = self.font.render(
                winner_text,
                True,
                self.colors['black']
            )
            self.screen.blit(
                text_surface,
                (self.window_size // 2, 10)
            )

    def handle_click(self, pos):
        """Handle mouse click events."""
        if self.winner:
            return

        x, y = pos
        board_x = (x - self.board_margin) // self.cell_size
        board_y = (y - self.board_margin) // self.cell_size

        if y < self.board_margin and self.current_player == 2:
            self._handle_reserve_click(x, 2)
        elif (y > self.window_size + self.board_margin and 
              self.current_player == 1):
            self._handle_reserve_click(x, 1)
        elif 0 <= board_y < 3 and 0 <= board_x < 3:
            self._handle_board_click(board_y, board_x)

    def _handle_reserve_click(self, x, player):
        """Handle clicks in the reserve area."""
        piece_x = (x - self.board_margin) // self.cell_size
        if 0 <= piece_x < 3:
            size = 2 - piece_x
            if self.board.reserve_pieces[player][size]:
                self.selected_piece = ('reserve', player, size)
                self.dragging = True
                self.drag_pos = (x, 
                               self.board_margin // 2 if player == 2 
                               else self.window_size + self.board_margin * 1.5)
                self.dragging_piece_size = size

    def _handle_board_click(self, row, col):
        """Handle clicks on the game board."""
        if not self.selected_piece:
            stack = self.board.get_stack(row, col)
            if stack and stack[-1].player == self.current_player:
                self.selected_piece = (row, col)
                self.dragging = True
                self.drag_pos = (
                    col * self.cell_size + self.cell_size // 2 + self.board_margin,
                    row * self.cell_size + self.cell_size // 2 + self.board_margin
                )
                self.dragging_piece_size = stack[-1].size
        else:
            self._try_move(row, col)

    def _try_move(self, row, col):
        """Attempt to make a move on the board."""
        if isinstance(self.selected_piece, tuple):
            if self.selected_piece[0] == 'reserve':
                _, player, size = self.selected_piece
                if self.board.place_from_reserve(player, size, row, col):
                    self._end_turn()
            else:
                src_row, src_col = self.selected_piece
                if self.board.is_valid_move(
                    src_row,
                    src_col,
                    row,
                    col,
                    self.current_player
                ):
                    self.board.move_piece(src_row, src_col, row, col)
                    self._end_turn()

        self._reset_selection()

    def _end_turn(self):
        """End the current player's turn."""
        self.current_player = 3 - self.current_player
        self.winner = self.board.check_winner()

    def _reset_selection(self):
        """Reset piece selection and dragging state."""
        self.selected_piece = None
        self.dragging = False
        self.drag_pos = None

    def run(self):
        """Main game loop."""
        running = True
        while running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    self.drag_start = event.pos
                    self.handle_click(event.pos)
                elif event.type == pygame.MOUSEBUTTONUP:
                    if self.dragging:
                        self._handle_drop(event.pos)
                elif event.type == pygame.MOUSEMOTION:
                    if self.dragging:
                        self._handle_drag(event.pos)

            self.draw_board()
            pygame.display.flip()

        pygame.quit()
        sys.exit()

    def _handle_drop(self, pos):
        """Handle piece drop events."""
        x, y = pos
        board_x = (x - self.board_margin) // self.cell_size
        board_y = (y - self.board_margin) // self.cell_size
        
        if 0 <= board_y < 3 and 0 <= board_x < 3:
            self._try_move(board_y, board_x)
        
        self._reset_selection()
        self.shadow_pos = None
        self.dragging_piece_size = None

    def _handle_drag(self, pos):
        """Handle piece dragging events."""
        self.drag_pos = pos
        x, y = pos
        board_x = (x - self.board_margin) // self.cell_size
        board_y = (y - self.board_margin) // self.cell_size
        
        if 0 <= board_x < 3 and 0 <= board_y < 3:
            self.shadow_pos = (board_y, board_x)
        else:
            self.shadow_pos = None

if __name__ == "__main__":
    game = GobbletGame()
    game.run()