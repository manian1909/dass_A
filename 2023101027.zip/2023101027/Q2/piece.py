

class Piece:
    def __init__(self, player, size):
        self.player = player  # 1 or 2
        self.size = size    # 0 (smallest) to 2 (largest)
