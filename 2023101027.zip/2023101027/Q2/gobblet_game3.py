"""Main module for the Gobblet game implementation using Pygame."""

import sys
from typing import Optional, Tuple, Dict
import pygame
from board3 import Board

class GobbletGame:
    """Main game class handling the GUI and game logic."""

    def __init__(self):
        """Initialize the game window and game state."""
        if not pygame.get_init(): #pylint: disable=no-member
            pygame.init() #pylint: disable=no-member
        self.window_size = 650
        self.cell_size = self.window_size // 3
        self.piece_size_mult = self.cell_size // 15
        self.reserve_height = 100
        self.board_margin = 50

        self.screen = pygame.display.set_mode((
            self.window_size + 2 * self.board_margin,
            self.window_size + 2 * self.board_margin
        ))
        pygame.display.set_caption('Gobblet Game (3x3)')

        # Game state
        self.board = Board()
        self.current_player = 1
        self.winner = None
        self.font = pygame.font.Font(None, 36)

        # Colors
        self.colors: Dict[str, Tuple[int, int, int]] = {
            'black': (0, 0, 0),
            'white': (255, 255, 255),
            'gray': (128, 128, 128),
            'red': (255, 0, 0),
            'yellow': (255, 255, 0)
        }

        # Display state
        self.zoom = 1.0
        self.selected_piece = None
        self.shadow_pos = None
        self.dragging = False
        self.drag_piece = None
        self.drag_pos = None
        self.drag_start = None
        self.drag_offset = None
        self.dragging_piece_size = None

        # Game rules state
        self.touched_piece = None
        self.must_move_touched = False
        self.last_clicked_pos = None

    def draw_board(self) -> None:
        """Draw the game board and all pieces."""
        self.screen.fill(self.colors['white'])
        self._draw_grid()
        self._draw_pieces()
        self._draw_reserve_pieces()
        self._draw_game_info()
        if self.dragging and self.shadow_pos:
            self._draw_shadow()

    def _draw_grid(self) -> None:
        """Draw the game board grid."""
        for i in range(3):
            for j in range(3):
                pygame.draw.rect(
                    self.screen,
                    self.colors['black'],
                    (j * self.cell_size + self.board_margin,
                     i * self.cell_size + self.board_margin,
                     self.cell_size,
                     self.cell_size),
                    2
                )

    def _draw_pieces(self) -> None:
        """Draw all pieces on the board."""
        for i in range(3):
            for j in range(3):
                pieces = self.board.get_stack(i, j)
                if pieces:
                    top_piece = pieces[-1]
                    color = (self.colors['yellow'] if top_piece.player == 1
                            else self.colors['red'])
                    self._draw_piece(i, j, top_piece.size, color)

    def _draw_piece(self, row: int, col: int, size: int,
                   color: Tuple[int, int, int]) -> None:
        """Draw a single piece."""
        radius = (size + 1) * self.piece_size_mult
        center = (col * self.cell_size + self.cell_size // 2 + self.board_margin,
                 row * self.cell_size + self.cell_size // 2 + self.board_margin)
        pygame.draw.circle(self.screen, color, center, radius)

    def _draw_reserve_pieces(self) -> None:
        """Draw reserve pieces for both players."""
        self._draw_player_reserve(2, self.board_margin // 2)
        self._draw_player_reserve(1, self.window_size + self.board_margin * 1.5)

    def _draw_player_reserve(self, player: int, y_pos: float) -> None:
        """Draw reserve pieces for a specific player."""
        x_pos = self.board_margin
        color = self.colors['red'] if player == 2 else self.colors['yellow']
        for size in range(3):
            for _ in self.board.reserve_pieces[player][2-size]:
                radius = (2-size + 1) * 20
                pygame.draw.circle(
                    self.screen,
                    color,
                    (int(x_pos + self.cell_size // 2), int(y_pos)),
                    radius
                )
                x_pos += self.cell_size

    def _draw_shadow(self) -> None:
        """Draw shadow for currently dragged piece."""
        row, col = self.shadow_pos
        shadow_radius = (self.dragging_piece_size + 1) * self.piece_size_mult
        shadow_center = (
            col * self.cell_size + self.cell_size // 2 + self.board_margin,
            row * self.cell_size + self.cell_size // 2 + self.board_margin
        )
        pygame.draw.circle(
            self.screen,
            self.colors['gray'],
            shadow_center,
            shadow_radius,
            3
        )

    def _draw_game_info(self) -> None:
        """Draw game status information."""
        current = 'YELLOW' if self.current_player == 1 else 'RED'
        player_text = f"Current Player: {current}"
        text_surface = self.font.render(
            player_text,
            True,
            self.colors['black']
        )
        self.screen.blit(text_surface, (self.board_margin, 10))

        if self.winner:
            winner = 'YELLOW' if self.winner == 1 else 'RED'
            winner_text = f"Winner: {winner}!"
            text_surface = self.font.render(
                winner_text,
                True,
                self.colors['black']
            )
            self.screen.blit(
                text_surface,
                (self.window_size // 2, 10)
            )

    def handle_click(self, pos: Tuple[int, int]) -> None:
        """Handle mouse click events."""
        if self.winner:
            return

        x, y = pos
        board_x = (x - self.board_margin) // self.cell_size
        board_y = (y - self.board_margin) // self.cell_size

        if y < self.board_margin and self.current_player == 2:
            self._handle_reserve_click(x, 2)
        elif y > self.window_size + self.board_margin and self.current_player == 1:
            self._handle_reserve_click(x, 1)
        elif 0 <= board_y < 3 and 0 <= board_x < 3:
            self._handle_board_click(board_y, board_x) #pylint: disable=no-member

    def _handle_reserve_click(self, x: int, player: int) -> None:
        """Handle clicks in the reserve area."""
        piece_x = (x - self.board_margin) // self.cell_size
        if 0 <= piece_x < 3:
            size = 2 - piece_x
            if self.board.reserve_pieces[player][size]:
                self.selected_piece = ('reserve', player, size)
                self.dragging = True
                self.drag_pos = (x, self.board_margin // 2 if player == 2
                               else self.window_size + self.board_margin * 1.5)
                self.dragging_piece_size = size

    def run(self) -> None:
        """Main game loop."""
        running = True
        while running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT: #pylint: disable=no-member
                    running = False
                elif event.type == pygame.MOUSEBUTTONDOWN: #pylint: disable=no-member
                    self.drag_start = event.pos
                    self.handle_click(event.pos)
                elif event.type == pygame.MOUSEBUTTONUP: #pylint: disable=no-member
                    if self.dragging:
                        self._handle_drop(event.pos)
                elif event.type == pygame.MOUSEMOTION: #pylint: disable=no-member
                    if self.dragging:
                        self._handle_drag(event.pos)

            self.draw_board()
            pygame.display.flip()

        pygame.quit() #pylint: disable=no-member
        sys.exit()

if __name__ == "__main__":
    game = GobbletGame()
    game.run()
